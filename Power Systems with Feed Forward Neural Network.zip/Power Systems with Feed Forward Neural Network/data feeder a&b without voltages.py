#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score
import tensorflow as tf
import numpy as np


# In[3]:


# Load your Excel file
df_Q = pd.read_excel(r"C:\Users\hp Elitebook\Downloads\FEEDERA\FeederA_data.xlsx")
df_P = pd.read_excel(r"C:\Users\hp Elitebook\Downloads\FEEDERA\FeederA_P.xlsx")
# Optional: clean column names
df_P.columns = df_P.columns.str.strip()
df_Q.columns = df_Q.columns.str.strip()


# In[4]:


# Combine both dataframes side-by-side
df_combined = pd.concat([df_P, df_Q], axis=1)


# In[7]:


V_ref = 1.0        # Reference voltage (pu)
alpha = 0.0005     # Weight for P
beta = 0.0003      # Weight for Q
V_simulated = V_ref - (alpha * df_P.sum(axis=1)) - (beta * df_Q.sum(axis=1))
y = V_simulated   
# Voltage to be predicted
X = df_combined
# Remove any datetime columns
X = df_combined.select_dtypes(include=['float64', 'int64'])

# Normalize input and output
scaler_X = StandardScaler()
scaler_y = StandardScaler()

X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y.values.reshape(-1, 1))


# In[9]:


# X_scaled, y_scaled are ready
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y_scaled, test_size=0.2, random_state=42
)


# In[10]:


import tensorflow as tf
from sklearn.metrics import mean_squared_error, r2_score

# Build the neural network
model = tf.keras.Sequential([
    tf.keras.layers.Dense(128, activation='relu', input_shape=(X_train.shape[1],)),
    tf.keras.layers.Dropout(0.2),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(32, activation='relu'),
    tf.keras.layers.Dense(1)  # Output: predicted voltage
])

#Compile the model
model.compile(
    optimizer='adam',
    loss='mse',
    metrics=['mae']
)

# Early stopping callback
early_stop = tf.keras.callbacks.EarlyStopping(
    monitor='val_loss',
    patience=10,
    restore_best_weights=True
)

# Train the model
history = model.fit(
    X_train, y_train,
    epochs=100,
    batch_size=16,
    validation_split=0.1,
    callbacks=[early_stop],
    verbose=1
)

# Evaluate the model
y_pred_scaled = model.predict(X_test)
y_pred = scaler_y.inverse_transform(y_pred_scaled)
y_actual = scaler_y.inverse_transform(y_test)

mse = mean_squared_error(y_actual, y_pred)
r2 = r2_score(y_actual, y_pred)

print(f"Mean Squared Error: {mse:.4f}")
print(f"R2 Score: {r2:.4f}")


# In[ ]:




